# Afnaan Ahamed — Engineering Portfolio Website

A responsive, dark technical personal portfolio built with plain HTML, CSS, and JavaScript for GitHub Pages. No build step or framework is required.

## Files

- `index.html` — page content and structure
- `styles.css` — layout, colors, responsive styles, and project illustrations
- `script.js` — mobile navigation and current year
- `assets/favicon.svg` — small AA icon

## Preview locally

1. Download and extract the ZIP.
2. Open `index.html` in a modern browser.

For a closer local-server preview, use VS Code with the Live Server extension, or run `python -m http.server` from this folder and open `http://localhost:8000`.

## Publish with GitHub Pages

1. Sign in to GitHub: https://github.com/
2. Create a **public** repository named `YOUR-USERNAME.github.io` (replace `YOUR-USERNAME` with your actual GitHub username).
3. Upload the files and folders from this package to the repository root. The root should contain `index.html`, `styles.css`, `script.js`, and `assets/`.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then save.
7. Wait for GitHub Pages to publish. Your site URL will be `https://YOUR-USERNAME.github.io/`.

If you instead use a repository with another name, GitHub Pages generally publishes at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/` when configured as a project site.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Personalize before publishing

Search `index.html` for the following and update anything that needs correction:

- Confirm your degree title, institution, and dates.
- Confirm your internship title, company name, and dates.
- GitHub profile is linked: https://github.com/afnaanahamed446-cyber. Add your verified LinkedIn URL when ready.
- Add actual project photos, screenshots, approved schematics, repository links, and measured results if available.
- Remove any details that are confidential or not approved for public sharing.

The email link is set to `afnaanahamed446@gmail.com`, based on the information provided.

## Accuracy notes

- No LinkedIn or GitHub URLs were invented.
- The project visuals are CSS/SVG illustrations, not photos of your actual hardware.
- The skills section's progress bars are decorative and are not measured proficiency scores. You may remove them if you prefer.
- The SSPC page mentions high-voltage design considerations; it is not a validated or safety-certified design.
- IoT and computer-vision descriptions are intentionally high-level where exact implementation details or results were not supplied.

## Custom domain (optional)

You can later buy a domain and configure it in **Settings → Pages → Custom domain**. A custom domain is optional; the default GitHub Pages address is enough to start.


## Resume download and ongoing updates

The site now has a Resume section and a download button that points to:

`assets/Afnaan_Ahamed_Resume.pdf`

The PDF itself is not included because you have not supplied the resume file in this step. To enable the button:
1. Put your latest resume PDF in the `assets` folder.
2. Name it exactly `Afnaan_Ahamed_Resume.pdf`.
3. Upload the updated `assets` folder to your GitHub repository and commit the changes.

### Best way to keep your resume updated

For a simple and reliable setup, keep one canonical PDF file at that exact path. Whenever you update your resume, replace that PDF with the new version and commit the change. The website's download button can stay the same.

If you prefer to update your resume without uploading the website files each time, use a stable public Google Drive PDF link or another permanent file-hosting link and point the button to it. Make sure sharing is set to anyone with the link, and verify the link opens the PDF directly. A repository-hosted PDF is usually cleaner for a technical portfolio, while a stable external link can be easier for frequent updates.
